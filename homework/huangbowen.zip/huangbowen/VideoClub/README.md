refactoring-fowler-example
==========================

Java code example to teach  basic refactoring  concepts 
